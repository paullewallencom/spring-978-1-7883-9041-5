simple-reactor-demo - contains code for reactor API.
simple-rx-java-demo - contains code for RxJava API.
SpringWebFluxDemo - contains code for WebFlux in Spring.