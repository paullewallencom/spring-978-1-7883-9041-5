package com.nilangpatel.blogpress;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogpressApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlogpressApplication.class, args);
	}
}
