SpringOnlyAuth - contain code for doing authentication with OAuth only
SpringOnlyLDAP - contain code for doing authentication with LDAP only
SpringLdapAndOAth - contain code for dual authentication with LDAP and OAuth both.
SpringCustomAuthorization - contains code for Custom Authorization server
SpringAuthResource - contains code for Resource Server.