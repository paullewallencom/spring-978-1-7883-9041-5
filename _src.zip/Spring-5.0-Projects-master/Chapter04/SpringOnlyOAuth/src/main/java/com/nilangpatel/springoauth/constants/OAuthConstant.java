package com.nilangpatel.springoauth.constants;

public interface OAuthConstant {

	/* Page title constants  */
	String PAGE_TITLE = "pageTitle";
	
	String TITLE_HOME_PAGE = "Home";
	String TITLE_PRIVATE_PAGE = "Private";
	String TITLE_LOGIN_PAGE = "Login";
}
