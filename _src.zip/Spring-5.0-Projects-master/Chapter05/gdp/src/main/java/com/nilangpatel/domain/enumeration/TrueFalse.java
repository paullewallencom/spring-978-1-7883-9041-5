package com.nilangpatel.domain.enumeration;

/**
 * The TrueFalse enumeration.
 */
public enum TrueFalse {
    T, F
}
