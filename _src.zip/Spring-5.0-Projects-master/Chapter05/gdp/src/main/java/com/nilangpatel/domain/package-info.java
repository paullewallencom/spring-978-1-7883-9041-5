/**
 * JPA domain objects.
 */
package com.nilangpatel.domain;
