/**
 * Spring Data JPA repositories.
 */
package com.nilangpatel.repository;
