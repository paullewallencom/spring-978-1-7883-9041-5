/**
 * Spring Security configuration.
 */
package com.nilangpatel.security;
