/**
 * Data Transfer Objects.
 */
package com.nilangpatel.service.dto;
