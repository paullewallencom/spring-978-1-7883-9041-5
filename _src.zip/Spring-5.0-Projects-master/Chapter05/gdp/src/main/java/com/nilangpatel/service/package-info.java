/**
 * Service layer beans.
 */
package com.nilangpatel.service;
