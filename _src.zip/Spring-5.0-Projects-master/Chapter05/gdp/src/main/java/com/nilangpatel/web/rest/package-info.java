/**
 * Spring MVC REST controllers.
 */
package com.nilangpatel.web.rest;
