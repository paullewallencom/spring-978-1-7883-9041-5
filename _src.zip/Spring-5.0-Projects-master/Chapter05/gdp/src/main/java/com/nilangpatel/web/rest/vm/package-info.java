/**
 * View Models used by Spring MVC REST controllers.
 */
package com.nilangpatel.web.rest.vm;
